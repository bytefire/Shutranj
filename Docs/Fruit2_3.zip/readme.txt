This software is provided as-is with not warranty implied or otherwise.  Some of the options are untested and my not be working as intended.  Feel free to report bugs (other than that Fruit lost) to rtg97229@yahoo.com.  
The Play Style option �Gambit� is not working at this time and will use the �Very-Aggressive� setting instead when this is set.  I am unlikely to go back and finish this in Fruit.  I had the theory in place but did not have time to implement this idea that is questionable at best as to how well it could work.  The idea is that if a king attack is above ATK_Margin and you are down on material score then compensate a percent based on king attack- ATK_Margin back to the material score up to MAT_Loss_CAP.  ATK_Margin and MAT_Loss_CAP are of course variable to be set.  I came up with this idea not as something to make a program play stronger but to make it play some exciting sacrificing moves that it otherwise would not have.  

Some of the UCI options
Play Style: this affects king attack and level.
Pawn Shield Hard: This affects the penalty for defects in pawn shielding.
Pawn Shield Soft: This affects the penalty of defects in pawn shielding as it is combine with penalties given for your king being attacked. 
Use PPP: This is a bonus for having more pieces available for advancing your passed pawn then the opponent has available for stopping it.  
PPExt: This is a passed pawn extension.  I think it is good but I turned it off when I was testing with no search extensions in main search. 

I am sure I missed a lot. Fruit is programmed by Fabien Letouzey.  Thank you to every one in the computer chess community including but not limited to Robert W. Allgeuer, Omar Skulason, Roger Brown, Bryan Hofmann, Tord Romstad, Tom Likens, Wilhelm Hudetz, Dann Corbit, Leo Dijksman, Heinz van Kempen, Joachim Rang, Nolan Denson, Mircea Hrubaru, Marc Lacrosse, Thorsten Czub, Aaron Gordon, Salvo Spitaleri, Daniel Mehrmann and so many more.  

Thanks for using Fruit and I hope you enjoy.

Thanks,
Ryan

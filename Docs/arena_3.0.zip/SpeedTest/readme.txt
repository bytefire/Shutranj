This progam calculates a chess- specific rating
with a built-in real chess program for use with
the chess GUI Arena (www.playwitharena.com).

Use this program at your own risk. No warranty
of any kind.

Martin Blume 2007